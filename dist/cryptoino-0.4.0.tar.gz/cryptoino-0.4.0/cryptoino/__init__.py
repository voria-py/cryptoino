"""
Cryptoino Project
"""

__author__ = 'Amirhossein Khosravi'
__email__ = "me@amirkho.ir"
__version__ = '0.1.0'

from .cryptoino import Coin

__all__ = [
       'Coin',
        ]